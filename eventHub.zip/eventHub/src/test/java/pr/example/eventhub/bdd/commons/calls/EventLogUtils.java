package pr.example.eventhub.bdd.commons.calls;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import pr.example.eventhub.api.eventLog.dto.EventLogInCreate;
import pr.example.eventhub.api.eventLog.dto.EventLogOut;

@Component
public class EventLogUtils {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("server.port")
    int port;
    RestTemplate restTemplate;

    public EventLogUtils(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public void declareEventLog(String label, String schema) {

        String url = urlEventLogPrefix();
        EventLogInCreate eventLogInCreate = new EventLogInCreate(label, schema);
        restTemplate.postForEntity(url, eventLogInCreate, EventLogOut.class);
    }

    private String urlEventLogPrefix() {
        return "https://127.0.0.1:"+port+"/v1/eventLogs/";
    }
}
