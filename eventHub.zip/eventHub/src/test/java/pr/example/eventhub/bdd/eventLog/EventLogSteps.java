package pr.example.eventhub.bdd.eventLog;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Test;

public class EventLogSteps {

    @When("an event log named TEST is declared with the schema SCHEMA")
    public void declareEventLog() {
        System.out.println("declareEventLog");
    }


    @When("an event log exixts with the schema SCHEMA")
    public void existsEventLog() {
        System.out.println("exixts");
    }

}
