package pr.example.eventhub.api.common.dto;

import lombok.Data;

@Data
public class Error {
    private String errorMessage;
}
