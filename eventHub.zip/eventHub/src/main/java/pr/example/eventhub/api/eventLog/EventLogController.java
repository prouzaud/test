package pr.example.eventhub.api.eventLog;

import org.springframework.web.bind.annotation.*;
import pr.example.eventhub.api.eventLog.dto.*;
import pr.example.eventhub.domain.EventLogService;
import pr.example.eventhub.model.EventLog;

@RestController("/v1/eventLogs")
public class EventLogController {
    private final EventLogMapper mapper;
    private final EventLogChecker checker;
    private final EventLogService eventLogService;

    public EventLogController(EventLogMapper mapper, EventLogChecker checker, EventLogService eventLogService) {
        this.mapper = mapper;
        this.checker = checker;
        this.eventLogService = eventLogService;
    }

    @PostMapping
    public EventLogOut create(@RequestBody EventLogInCreate eventLogInCreate) {

        checker.check(eventLogInCreate);
        EventLog eventLog = eventLogService.create(eventLogInCreate.getLabel(), eventLogInCreate.getSchema());
        return mapper.map(eventLog);
    }

    @GetMapping("/{uuid}")
    public EventLogOut getByUuid(@PathVariable("uuid") String uuid) {

        EventLog eventLog = eventLogService.findByUuid(uuid);
        return mapper.map(eventLog);
    }
}
