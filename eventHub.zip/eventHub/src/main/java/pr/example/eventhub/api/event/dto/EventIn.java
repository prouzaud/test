package pr.example.eventhub.api.event.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class EventIn {

    private String payload;
    private LocalDateTime businessDate;
}
