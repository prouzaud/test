package pr.example.eventhub.api.event.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
public class EventsAddIn {
    private String eventLogUuid;
    private List<EventIn> events = new ArrayList<>();
}
