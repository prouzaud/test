package pr.example.eventhub.api.eventLog.dto;

import lombok.Data;

@Data
public class EventLogInCreate {

    private String label;
    private String schema;

    public EventLogInCreate(String label, String schema) {
        this.label = label;
        this.schema = schema;
    }
}
