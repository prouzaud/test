package pr.example.eventhub.domain;

import org.springframework.stereotype.Service;
import pr.example.eventhub.domain.repositories.EventLogRepository;
import pr.example.eventhub.domain.repositories.EventRepository;
import pr.example.eventhub.exceptions.NotFoundException;
import pr.example.eventhub.exceptions.UnauthorizedOperationException;
import pr.example.eventhub.model.Event;
import pr.example.eventhub.model.EventLog;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class EventService {

    private final EventLogRepository eventLogRepository;
    private final EventRepository eventRepository;

    public EventService(final EventLogRepository eventLogRepository, EventRepository eventRepository) {
        this.eventLogRepository = eventLogRepository;
        this.eventRepository = eventRepository;
    }

    public void addEvent(String eventLogUuid, String payload, LocalDateTime businessDateTime) {
        EventLog eventLog = findAndCheckEventLog(eventLogUuid);
        Event event = new Event(eventLog.getId(), payload, businessDateTime);
        eventRepository.save(event);
    }

    private EventLog findAndCheckEventLog(String eventLogUuid) {
        EventLog eventLog = eventLogRepository.findByUuid(eventLogUuid);
        if (eventLog == null) {
            throw new NotFoundException("Unable to add events: unknown event log.");
        }
        if (!eventLog.isActive()) {
            throw new UnauthorizedOperationException("This event log is not active.");
        }
        return eventLog;
    }
}
