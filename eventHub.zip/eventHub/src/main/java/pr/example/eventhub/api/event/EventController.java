package pr.example.eventhub.api.event;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import pr.example.eventhub.api.event.dto.EventChecker;
import pr.example.eventhub.api.event.dto.EventMapper;
import pr.example.eventhub.api.event.dto.EventIn;
import pr.example.eventhub.api.event.dto.EventsAddIn;
import pr.example.eventhub.api.event.dto.EventsAddOut;
import pr.example.eventhub.domain.EventService;

@RestController
public class EventController {

    final EventMapper mapper;
    final EventChecker checker;
    final EventService eventService;
    public EventController(EventMapper mapper, EventChecker checker, EventService eventService) {
        this.mapper = mapper;
        this.checker = checker;
        this.eventService = eventService;
    }

    @PostMapping("/v1/events")
    public EventsAddOut addEvents(@RequestBody EventsAddIn eventsAddIn) {

        checker.check(eventsAddIn);
        for (EventIn event : eventsAddIn.getEvents()) {
            eventService.addEvent(eventsAddIn.getEventLogUuid(), event.getPayload(), event.getBusinessDate());
        }
        return new EventsAddOut(eventsAddIn.getEvents().size());
    }
}
