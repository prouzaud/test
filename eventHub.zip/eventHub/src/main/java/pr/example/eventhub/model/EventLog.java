package pr.example.eventhub.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity(name = "EVENT_LOG")
public class EventLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  long id;
    @Column
    private String label;
    @Column
    private String uuid;

    @Column
    private boolean active = false;
    @Column
    private String schema;

    public EventLog(String label, String schema) {
        this.label = label;
        this.schema = schema;
    }

    public EventLog() {}
}
