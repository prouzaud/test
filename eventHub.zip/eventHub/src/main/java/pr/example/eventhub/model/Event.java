package pr.example.eventhub.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity(name = "EVENT")
@Data
public class Event {

    @Transient
    DateTimeFormatter formatter = DateTimeFormatter.ISO_INSTANT;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    @Column
    private long eventLogId;

    @Column
    LocalDateTime creationDateTime = LocalDateTime.now();
    @Column
    LocalDateTime businessDateTime;
    @Column
    private String payload;

    public Event() {}

    public Event(long eventLogId, String payload, LocalDateTime businessDateTime) {
        this.eventLogId = eventLogId;
        this.creationDateTime = LocalDateTime.now();
        this.businessDateTime = businessDateTime == null ? this.creationDateTime : businessDateTime;
        this.payload = payload;
    }

    private String buildExternalId() {
        return formatter.format(creationDateTime);
    }
}
