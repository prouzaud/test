package pr.example.eventhub.api.eventLog.dto;

import lombok.Data;

@Data 
public class EventLogOut {

    private String label;
    private boolean active;
    private String schema;
    private String uuid;
}
