package pr.example.eventhub.domain.repositories;

import org.springframework.data.repository.ListCrudRepository;
import pr.example.eventhub.model.Event;

public interface EventRepository extends ListCrudRepository<Event, Long> {


}
