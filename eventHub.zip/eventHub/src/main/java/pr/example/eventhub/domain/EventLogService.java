package pr.example.eventhub.domain;

import org.springframework.stereotype.Service;
import pr.example.eventhub.domain.repositories.EventLogRepository;
import pr.example.eventhub.model.EventLog;
import pr.example.eventhub.exceptions.NotFoundException;

import java.util.UUID;

@Service
public class EventLogService {

    private final EventLogRepository eventLogRepository;

    public EventLogService(final EventLogRepository eventLogRepository) {
        this.eventLogRepository = eventLogRepository;
    }

    public synchronized EventLog create(final String label, final String schema) {

        final EventLog eventLog = new EventLog(label, schema);
        eventLog.setUuid(chooseUniqueUuid());
        eventLogRepository.save(eventLog);
        return eventLog;
    }

    private String chooseUniqueUuid() {
        String uuid = null;
        do {
            uuid = UUID.randomUUID().toString();
        } while (eventLogRepository.countFirstByUuid(uuid) > 0);
        return uuid;
    }

    public EventLog findByUuid(final String uuid)
    {
        EventLog eventLog =  eventLogRepository.findByUuid(uuid);
        if (eventLog == null) {
            throw new NotFoundException("No event log for the given uuid.");
        }
        return  eventLog;
    }
}
