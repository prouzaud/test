package pr.example.eventhub.model;

public class Subscription {

    private long id;
    private String uid;

    private String appplicationCode;

    private String libelle;
}
