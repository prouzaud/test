package pr.example.eventhub.api.eventLog.dto;

import org.springframework.stereotype.Component;
import pr.example.eventhub.model.EventLog;

@Component
public class EventLogMapper {

    public EventLogOut map(EventLog eventLog) {
        EventLogOut eventLogOut = new EventLogOut();
        eventLogOut.setLabel(eventLog.getLabel());
        eventLogOut.setActive(eventLog.isActive());
        eventLogOut.setUuid(eventLog.getUuid());
        eventLogOut.setSchema(eventLog.getSchema());
        return eventLogOut;
    }
}
