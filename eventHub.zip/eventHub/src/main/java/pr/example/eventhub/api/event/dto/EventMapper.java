package pr.example.eventhub.api.event.dto;

import org.springframework.stereotype.Component;

@Component
public class EventMapper {


}
