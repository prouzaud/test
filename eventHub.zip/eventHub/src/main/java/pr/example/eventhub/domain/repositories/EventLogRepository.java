package pr.example.eventhub.domain.repositories;

import org.springframework.data.repository.ListCrudRepository;
import org.springframework.stereotype.Repository;
import pr.example.eventhub.model.EventLog;

@Repository
public interface EventLogRepository extends ListCrudRepository<EventLog, Long> {

    long countFirstByUuid(String uuid);

    EventLog findByUuid(String uuid);
}
