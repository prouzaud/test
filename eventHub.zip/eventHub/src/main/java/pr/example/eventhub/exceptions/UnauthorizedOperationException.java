package pr.example.eventhub.exceptions;

import lombok.Data;

@Data
public class UnauthorizedOperationException extends RuntimeException {

    private String message;

    public UnauthorizedOperationException(String message) {
        this.message = message;
    }
}
