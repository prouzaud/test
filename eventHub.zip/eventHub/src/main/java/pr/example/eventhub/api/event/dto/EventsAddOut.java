package pr.example.eventhub.api.event.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor public class EventsAddOut {
    int numberOfAddedEvents;
}
