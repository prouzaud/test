package pr.example.eventhub.api.event.dto;

import org.springframework.stereotype.Component;

@Component
public class EventChecker {

    public void check(final EventsAddIn eventsAddIn) {

    }


}
