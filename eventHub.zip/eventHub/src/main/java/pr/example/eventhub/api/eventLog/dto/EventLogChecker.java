package pr.example.eventhub.api.eventLog.dto;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import pr.example.eventhub.exceptions.BadRequestException;
@Component
public class EventLogChecker {

    public void check(EventLogInCreate eventLogInCreate) {

        if (StringUtils.isEmpty(eventLogInCreate.getLabel())) {
            throw new BadRequestException("the label field is mandatory.");
        }
        if (StringUtils.isEmpty(eventLogInCreate.getSchema())) {
            throw new BadRequestException("the schema field is mandatory.");
        }
    }


}
